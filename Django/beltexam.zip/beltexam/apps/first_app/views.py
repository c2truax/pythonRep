from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User, Category, Job
import bcrypt

def index(request):
	return render(request, 'first_app/index.html')

def create(request):
	if request.method == "POST":
		errors = User.objects.validation(request.POST)
		if len(errors):
			for keys, value in errors.items():
				messages.error(request, value, extra_tags='reg')

			return redirect('/')
		else:
			hash = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt())
			print(hash)
			new_user = User.objects.create(first_name = request.POST['first_name'], last_name = request.POST['last_name'], email = request.POST['email'], password = hash)
			request.session['user_id'] = new_user.id
			return redirect('/dashboard/')
	else:
		return redirect('/')
	

def read(request):
	error = User.objects.login_validation(request.POST)
	if len(error):
		for keys, value in error.items():
			messages.error(request, value, extra_tags='login')

		return redirect('/')
	else:
		request.session['user_id'] = User.objects.get(email = request.POST['username']).id
		return redirect('/dashboard/')

def logout(request):
	request.session.clear()
	return redirect('/')

def dashboard(request):
	if 'user_id' not in request.session:
		return redirect('/')
	context= {
	'user': User.objects.get(id = request.session['user_id']),
	'alljobs': Job.objects.exclude(users = request.session['user_id']),
	'myjobs': Job.objects.filter(users=request.session['user_id']),
	}
	return render(request, 'first_app/dashboard.html', context)

def new(request):
	if 'user_id' not in request.session:
		return redirect('/')
	context= {
	'user': User.objects.get(id = request.session['user_id']),
	}
	return render(request, 'first_app/newjob.html', context)

def createjob(request):
	if request.method == "POST":
		errors = Job.objects.validation(request.POST)
		if len(request.POST['othercat']):
			category = Category.objects.create(cat_type = request.POST['othercat'])
		elif len(request.POST['category']):
			category = Category.objects.get(cat_type = request.POST['category'])
		else:
			errors['category'] = 'Category needs to be provided.'
		if len(errors):
			for keys, value in errors.items():
				messages.error(request, value)

			return redirect('/jobs/new/')
		else:
			new_job = Job.objects.create(title = request.POST['title'], desc = request.POST['desc'], location = request.POST['location'], category = category)
			new_job.users = User.objects.get(id=request.session['user_id']), 
			return redirect('/dashboard/')
	else:
		return redirect('/')

def edit(request,id):
	if 'user_id' not in request.session:
		return redirect('/')
	context= {
	'user': User.objects.get(id = request.session['user_id']),
	}
	return render(request, 'first_app/editjob.html', context)

def editjob(request,id):
	if 'user_id' not in request.session:
		return redirect('/')
	return redirect('/dashboard/')

def viewjob(request,id):
	if 'user_id' not in request.session:
		return redirect('/')
	context= {
	'user': User.objects.get(id = request.session['user_id']),
	}
	return render(request, 'first_app/viewjob.html', context)