from django.apps import AppConfig


class FirstAssignmentConfig(AppConfig):
    name = 'first_assignment'
